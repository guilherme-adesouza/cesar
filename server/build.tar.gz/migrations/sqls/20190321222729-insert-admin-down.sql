DELETE FROM player WHERE name='admin';
DELETE FROM player WHERE name='guilherme-souza';
DELETE FROM player WHERE name='junior-lenhart';
