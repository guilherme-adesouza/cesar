DELETE FROM player WHERE name='Fernando Augusto Giordani';
DELETE FROM platform;
DELETE FROM genre;
DELETE FROM game;
